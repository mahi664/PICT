
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=0 max-scale = 0.4">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
</head>
<body>
 
<div class="container">
  <div class="card" style="margin: 200px;">
    <div class="card-header" style="background-color: #ffb74d;">Admin Login</div>
    <div class="card-body" style="background-color: #ffe0b2;">
      <form action="login.php" method="POST">
        <div class="form-group">
          <label for="email">Username:</label>
          <input type="text" class="form-control" id="email" placeholder="Username" name="user">
        </div>
        <div class="form-group">
          <label for="pwd">Password:</label>
          <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pswd">
        </div>
        <button type="submit" class="btn" style="background-color: #ffb74d">Submit</button>

      </form>
    </div> 
  </div>
</div>

</body>
</html>
