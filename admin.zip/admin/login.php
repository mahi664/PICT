<?php
include "connect.php";

session_start();

if(!empty($_POST['user']) && !empty($_POST['pswd']))
{
	if($_POST['user']=="admin" && $_POST['pswd']=="nimda")
	{
  		$_SESSION['user'] = $_POST['user'];
  		$_SESSION['pswd']  =$_POST['pswd'];
  		echo "<script>
            window.location.href = '/PICT/admin/request.php';</script>";	
  	}
  	else
  	{
  		echo "<script>alert('Invalid Username or Password!!!');
            window.location.href = '/PICT/admin/index.php';</script>";	
  	}
}
else
{
  echo "<script>alert('Username or Password can not be empty!!!');
            window.location.href = '/PICT/admin/index.php';</script>";
}


?>
