<?php
session_start();

include "connect.php";
//pdsubmit line70 how to give alert?

if(isset($_POST['pdsubmit'])){

	$row = $_SESSION['row'];
	
	$fullname = $row['fullname'];
	$contact = $row['contact'];
	$department = $row['department'];
	$designation = $row['designation'];
	$responsibility = $row['responsibility'];
	$eid = $row['eid'];
	$pdname = $_POST['pdname'];
	$pdemail = $_POST['pdemail'];
	$pdphone = $_POST['pdphone'];
	$pddept = $_POST['pddept'];
	$pddesg = $_POST['pddesg'];
	$pdresp = $_POST['pdresp'];

	$change = 0;


	if($pdname!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","fullname","Faculty","'.$pdname.'")';
		$query = $conn->query($sql);
		if($query){
			echo "updated1";
		}
		$change = 1;
		//add
	}
	if($pdphone!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","contact","Faculty","'.$pdphone.'")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated2";
		}
		$change = 1;
		//add
	}
	if($pddept!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","department","Faculty","'.$pddept.'")';		
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated3";
		}
		$change = 1;
		//add
	}
	if($pddesg!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","designation","Faculty","'.$pddesg.'")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated4";
		}
		$change = 1;
		//add
	}	
	if($pdresp!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","responsibility","Faculty","'.$pdresp.'")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated5";
		}		
		$change = 1;
		//add
	}

	if($change == 1){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php#qualifications'

		</script>";
	}

	if($change == 0){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php#personaltab';
		</script>";
	}	
}

//Experience tab
 if(isset($_POST['exsubmit'])){
 	$row = $_SESSION['row'];

 	$aoi = $row['aoi'];
	$texperience = $row['texperience'];
	$iexperience = $row['iexperience'];
	$other = $row['other'];

	$eid = $row['eid'];
	$exaoi = $_POST['exaoi'];
	$extexperience = $_POST['extexperience'];
	$exiexperience = $_POST['exiexperience'];
	$exother = $_POST['exother'];

	$change = 0;

	if($exaoi!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","aoi","Faculty","'.$exaoi.'")';		
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated1";
		}		
		$change = 1;
		//add
	}
	if($extexperience!=""){
		$sql = 'INSERT INTO temp VALUES ("$eid","texperience","Faculty","$extexperience")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated2";
		}		
		$change = 1;
		//add
	}
	if($exiexperience!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","iexperience","Faculty","'.$exiexperience.'")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated3";
		}		
		$change = 1;
		//add
	}
	if($exother!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","other","Faculty","'.$exother.'")';		
		$sql = 'INSERT INTO temp VALUES ("$eid","other","Faculty","$exother")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated4";
		}		
		$change = 1;
		//add
	}
	if($change == 1){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php#journals'

		</script>";
	}

	if($change == 0){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php#experience';
		</script>";
	}	
 }

//Others tab
if(isset($_POST['odsubmit'])){
	$row = $_SESSION['row'];
	$eid = $row['eid'];
	$oddetails = $_POST['odother'];
	$change = 0;
	if($oddetails!=""){
		$sql = 'INSERT INTO temp VALUES ("'.$eid.'","other","Faculty","'.$oddetails.'")';
		$query = $conn->query($sql);
		if($query){
			echo "\nupdated4";
		}		
		$change = 1;
		//add
	}
	if($change == 1){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php'
		</script>";
	}

	if($change == 0){
		echo 
		"<script>
			window.location.href = '/facultyPage/editpage.php#other';
		</script>";
	}	
}

if(isset($_POST['qsubmit'])){
	$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$qlevel = $_POST['qlevel'];
	$qdegree = $_POST['qdegree'];
	$qspec = $_POST['qspec'];
	$quname = $_POST['quname'];
	$qcollege = $_POST['qcollege'];
	$qyear = $_POST['qyear'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$qid = $row['qid'];
		$eid = $row['eid'];

		if($qlevel[$i] != ""){
			//$query1 = 'UPDATE Qualifications SET level='.'\"'.$qlevel[$i].'\"'.' WHERE qid = \"'.$qid.'\"';
			$query1 = 'UPDATE Qualifications SET level='.'\"'.$qlevel[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';

			//$query1 = 'UPDATE Qualifications SET level='.'\"'.$qlevel[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","level","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}		
		}
		if($qdegree[$i] != ""){
			$query1 = 'UPDATE Qualifications SET degree='.'\"'.$qdegree[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","degree","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}		
		}
		if($qspec[$i] != ""){
			$query1 = 'UPDATE Qualifications SET specialization='.'\"'.$qspec[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","specialization","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated3";
			}		
		}
		if($quname[$i] != ""){
			$query1 = 'UPDATE Qualifications SET uname='.'\"'.$quname[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","uname","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}		
		}
		if($qcollege[$i] != ""){
			$query1 = 'UPDATE Qualifications SET college='.'\"'.$qcollege[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","college","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated5";
			}		
		}
		if($qyear[$i] != ""){
			$query1 = 'UPDATE Qualifications SET year='.'\"'.$qyear[$i].'\"'.' WHERE qid = '.'\"'.$qid.'\"';
			//$query1 = "UPDATE Qualifications SET level="."\'".$qlevel[$i]."\'"." WHERE qid = "."\'".$qid."\'";
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","year","Qualifications","'.$query1.'")';
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated6";
			}		
		}

		#increment
		$i = $i + 1;
	}
}

if(isset($_POST['jsubmit'])){
$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$jtitle = $_POST['jtitle'];
	$jtype = $_POST['jtype'];
	$jyear = $_POST['jyear'];
	$jdes = $_POST['jdes'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$jid = $row['jid'];
		$eid = $row['eid'];

		if($jtitle[$i] != ""){
			$query1 = 'UPDATE Journals SET title='.'\"'.$jtitle[$i].'\"'.' WHERE jid = '.'\"'.$jid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","title","Journals","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($jtype[$i] != ""){
			$query1 = 'UPDATE Journals SET type='.'\"'.$jtype[$i].'\"'.' WHERE jid = '.'\"'.$jid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","type","Journals","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}
			else{
				echo "not added";
			}		
		}		
		if($jyear[$i] != ""){
			$query1 = 'UPDATE Journals SET year='.'\"'.$jyear[$i].'\"'.' WHERE jid = '.'\"'.$jid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","year","Journals","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($jdes[$i] != ""){
			$query1 = 'UPDATE Journals SET description='.'\"'.$jdes[$i].'\"'.' WHERE jid = '.'\"'.$jid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","description","Journals","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}	
		#increment
		$i = $i + 1;
	}	
}


if(isset($_POST['bsubmit'])){
$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$bname = $_POST['bname'];
	$bpub = $_POST['bpub'];
	$byear = $_POST['byear'];
	$bdes = $_POST['bdes'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$bid = $row['bid'];
		$eid = $row['eid'];

		if($bname[$i] != ""){
			$query1 = 'UPDATE Books SET bname='.'\"'.$bname[$i].'\"'.' WHERE bid = '.'\"'.$bid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","bname","Books","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($bpub[$i] != ""){
			$query1 = 'UPDATE Books SET publication='.'\"'.$bpub[$i].'\"'.' WHERE bid = '.'\"'.$bid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","publication","Books","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($byear[$i] != ""){
			$query1 = 'UPDATE Books SET year='.'\"'.$byear[$i].'\"'.' WHERE bid = '.'\"'.$bid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","year","Books","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($bdes[$i] != ""){
			$query1 = 'UPDATE Books SET description='.'\"'.$bdes[$i].'\"'.' WHERE bid = '.'\"'.$bid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","description","Books","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}		
		#increment
		$i = $i + 1;
	}	
}

if(isset($_POST['csubmit'])){
$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$ctitle = $_POST['ctitle'];
	$ctype = $_POST['ctype'];
	$cyear = $_POST['cyear'];
	$cdetails = $_POST['cdetails'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$cid = $row['cid'];
		$eid = $row['eid'];

		if($ctitle[$i] != ""){
			$query1 = 'UPDATE Conferences SET ctitle='.'\"'.$ctitle[$i].'\"'.' WHERE cid = '.'\"'.$cid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","ctitle","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($ctype[$i] != ""){
			$query1 = 'UPDATE Conferences SET ctype='.'\"'.$ctype[$i].'\"'.' WHERE cid = '.'\"'.$cid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","ctype","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}
			else{
				echo "not added2";
			}		
		}
		if($cyear[$i] != ""){
			$query1 = 'UPDATE Conferences SET year='.'\"'.$cyear[$i].'\"'.' WHERE cid = '.'\"'.$cid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","year","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated3";
			}
			else{
				echo "not added3";
			}		
		}
		if($cdetails[$i] != ""){
			$query1 = 'UPDATE Conferences SET cdetails='.'\"'.$cdetails[$i].'\"'.' WHERE cid = '.'\"'.$cid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","cdetails","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}		
		#increment
		$i = $i + 1;
	}	
}


if(isset($_POST['ptsubmit'])){
$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$ptpatentno = $_POST['ptpatentno'];
	$pttitle = $_POST['pttitle'];
	$ptassignee = $_POST['ptassignee'];
	$ptcountry = $_POST['ptcountry'];
	$ptyear = $_POST['ptyear'];	
	$ptwebadd = $_POST['ptwebadd'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$pid = $row['pid'];
		$eid = $row['eid'];

		if($ptpatentno[$i] != ""){
			$query1 = 'UPDATE Patent SET patentno='.'\"'.$ptpatentno[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","patentno","Patent","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($pttitle[$i] != ""){
			$query1 = 'UPDATE Patent SET ptitle='.'\"'.$pttitle[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","ptitle","Patent","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}
			else{
				echo "not added2";
			}		
		}
		if($ptassignee[$i] != ""){
			$query1 = 'UPDATE Patent SET assignee='.'\"'.$ptassignee[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","assignee","Patent","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated3";
			}
			else{
				echo "not added3";
			}		
		}
		if($ptcountry[$i] != ""){
			$query1 = 'UPDATE Patent SET country='.'\"'.$ptcountry[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","country","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}
		if($ptyear[$i] != ""){
			$query1 = 'UPDATE Patent SET year='.'\"'.$ptyear[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","year","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated5";
			}
			else{
				echo "not added5";
			}		
		}		
		if($ptwebadd[$i] != ""){
			$query1 = 'UPDATE Patent SET webadd='.'\"'.$ptwebadd[$i].'\"'.' WHERE pid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","webadd","Conferences","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated6";
			}
			else{
				echo "not added6";
			}		
		}				
		#increment
		$i = $i + 1;
	}	
}

if(isset($_POST['condsubmit'])){
	$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$condioiu = $_POST['condioiu'];
	$condsdate = $_POST['condsdate'];
	$condedate = $_POST['condedate'];
	$condduration = $_POST['condduration'];	
	//$condview = $_POST['condview'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$pid = $row['csid'];
		$eid = $row['eid'];

		if($condioiu[$i] != ""){
			$query1 = 'UPDATE Consultancy SET ioiu='.'\"'.$condioiu[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","ioiu","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($condsdate[$i] != ""){
			$query1 = 'UPDATE Consultancy SET sdate='.'\"'.$condsdate[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","sdate","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}
			else{
				echo "not added2";
			}		
		}
		if($condedate[$i] != ""){
			$query1 = 'UPDATE Consultancy SET edate='.'\"'.$condedate[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","edate","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated3";
			}
			else{
				echo "not added3";
			}		
		}
		if($condduration[$i] != ""){
			$query1 = 'UPDATE Consultancy SET duration='.'\"'.$condduration[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","duration","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}
		/*if($condview[$i] != ""){
			$query1 = 'UPDATE Consultancy SET condview='.'\"'.$condview[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","duration","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}*/		
		#increment
		$i = $i + 1;
	}	
}

if(isset($_POST['frpsubmit'])){
	$trowcnt = (int)$_SESSION['rowcnt'];

	$i = 0;
	$frptitle = $_POST['frptitle'];
	$frpicoi = $_POST['frpicoi'];
	$frpduration = $_POST['frpduration'];
	$frpfamount = $_POST['frpfamount'];
	$frpfegency = $_POST['frpfegency'];
	$frpremark = $_POST['frpremark'];		
	//$condview = $_POST['condview'];	

	while ($i < $trowcnt) {
		# code...
		$rowname = "row".($i+1);
		$row = $_SESSION[$rowname];
		$pid = $row['fid'];
		$eid = $row['eid'];

		if($frptitle[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET ptitle='.'\"'.$frptitle[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","ptitle","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated1";
			}
			else{
				echo "not added";
			}		
		}
		if($frpicoi[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET picoi='.'\"'.$frpicoi[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","picoi","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated2";
			}
			else{
				echo "not added2";
			}		
		}
		if($frpduration[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET duration='.'\"'.$frpduration[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","duration","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated3";
			}
			else{
				echo "not added3";
			}		
		}
		if($frpfamount[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET famount='.'\"'.$frpfamount[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","famount","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}
		if($frpfegency[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET fegency='.'\"'.$frpfegency[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","fegency","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated5";
			}
			else{
				echo "not added5";
			}		
		}
		if($frpremark[$i] != ""){
			$query1 = 'UPDATE Fundedrp SET remark='.'\"'.$frpremark[$i].'\"'.' WHERE fid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","remark","Fundedrp","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated6";
			}
			else{
				echo "not added6";
			}		
		}
		/*if($condview[$i] != ""){
			$query1 = 'UPDATE Consultancy SET condview='.'\"'.$condview[$i].'\"'.' WHERE csid = '.'\"'.$pid.'\"';
			
			$sql = 'INSERT INTO temp VALUES ("'.$eid.'","duration","Consultancy","'.$query1.'")';
			
			$query = $conn->query($sql);
			if($query){
				echo "\nupdated4";
			}
			else{
				echo "not added4";
			}		
		}*/		
		#increment
		$i = $i + 1;
	}	
}

?>

















