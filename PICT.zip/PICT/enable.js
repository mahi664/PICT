function abc()
{
	document.getElementsByTagName("p").style.color="red";
}
abc();