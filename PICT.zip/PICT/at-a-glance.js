/*function callcard(){
	var content = '<div class="card-container col-lg-4 col-sm-6" ><div class="card"><div class="card-image"><img alt="Image comes here" src="/home/ask149/Website/Faculty/Front-page/default.png"></div><div class="card-body"><div class="title"><font style="color:blue;"><b>Name </b></font> Dr. Emmaunel M</div><div class="desc"><font style="color:blue;"><b>Contact No: </b></font>9999999999</div><div class="desc"><font style="color:blue;"><b>Email </b></font>emmanuelm@pict.edu</div><div class="desc"> <a href="<?php echo $link; ?>" ?>View Profile</a></div></div></div></div>';

	var container0 = document.getElementById("hod");	
	var count=1;
	var code = container0.innerHTML;
	for(var i=0;i<count;i++)
	{
		 code = code + content;
	}
	container0.innerHTML = code;

	var container1 = document.getElementById("professor");	
	var count=3;
	var code = container1.innerHTML;
	for(var i=0;i<count;i++)
	{
		 code = code + content;
	}
	container1.innerHTML = code;
	
	var count = 6;
	var container2 = document.getElementById("assistant");	
	var code = container2.innerHTML;
	for(var i=0;i<count;i++)
	{
		 code = code + content;
	}
	container2.innerHTML = code;
	
	var count = 8;
	var container3 = document.getElementById("associate");	
	var code = container3.innerHTML;
	for(var i=0;i<count;i++)
	{
		 code = code + content;
	}
	container3.innerHTML = code;
}*/